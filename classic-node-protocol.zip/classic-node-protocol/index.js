'use strict';

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Minecraft Classic Protocol v7 / ClassiCube – Node.js Library
 *
 * Zero-dependency implementation of the Minecraft Classic network protocol.
 * Supports full client and server implementations.
 *
 * @module classic-node-protocol
 * @version 1.4.3
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { createClient, ClassiCubeClient } = require('./lib/client');
const { createServer, ClassiCubeServer, ClientConnection } = require('./lib/server');
const encoder       = require('./lib/encoder');
const PacketDecoder = require('./lib/decoder');
const protocol      = require('./lib/protocol');
const level         = require('./lib/level');
const jugadorUUID   = require('./UUID/jugadorUUID');
const cpe           = require('./lib/cpe');
const auth          = require('./lib/auth');

const VERSION = '2.2.0';

function getVersion() { return VERSION; }

module.exports = {
  // ── Primary API ─────────────────────────────────────────────────────────
  createClient,
  createServer,

  // ── Classes ──────────────────────────────────────────────────────────────
  ClassiCubeClient,
  ClassiCubeServer,
  ClientConnection,
  PacketDecoder,

  // ── Low-level modules ────────────────────────────────────────────────────
  encoder,
  protocol,
  level,

  // ── Named constants re-exported at top level for convenience ─────────────
  BLOCKS:      protocol.BLOCKS,
  BLOCK_NAMES: protocol.BLOCK_NAMES,
  BLOCK_MODE:  protocol.BLOCK_MODE,
  USER_TYPE:   protocol.USER_TYPE,
  CPE_MAGIC:   protocol.CPE_MAGIC,

  // ── CPE module ────────────────────────────────────────────────────────────
  cpe,

  // ── CPE constants re-exported at top level ───────────────────────────────
  CPE_EXTENSIONS: protocol.CPE_EXTENSIONS,
  CPE_PACKETS:    protocol.CPE_PACKETS,
  ENV_COLOR:      cpe.ENV_COLOR,
  WEATHER:        cpe.WEATHER,
  MAP_ENV_PROPERTY: cpe.MAP_ENV_PROPERTY,
  ENTITY_PROPERTY:  cpe.ENTITY_PROPERTY,

  // ── UUID helpers ─────────────────────────────────────────────────────────
  jugadorUUID,

  // ── Auth ──────────────────────────────────────────────────────────────────
  /** Server-side: MPPass verification + heartbeat to classicube.net */
  ClassiCubeAuth:    auth.ClassiCubeAuth,
  /** Client/Bot-side: log in to a classicube.net account */
  ClassiCubeAccount: auth.ClassiCubeAccount,
  /** Generate a random salt string (for custom integrations) */
  generateSalt:      auth.generateSalt,
  /** Compute the expected MPPass: MD5(salt + username) */
  computeMPPass:     auth.computeMPPass,
  /** Verify a player's MPPass against a salt */
  verifyMPPass:      auth.verifyMPPass,
  /** Full auth module */
  auth,

  // ── Metadata ─────────────────────────────────────────────────────────────
  VERSION,
  getVersion,
};
