'use strict';

const crypto = require('crypto');

/**
 * Generate a deterministic UUID v3-style (MD5) from a username.
 * ClassiCube uses MD5-based UUIDs for player identification.
 *
 * @param   {string} username
 * @returns {string} UUID string (e.g. "550e8400-e29b-41d4-a716-446655440000")
 */
function generarUUID(username) {
  const hash = crypto.createHash('md5').update(username).digest();
  // Set version bits (v3 = 0x30) and variant bits (RFC 4122)
  hash[6] = (hash[6] & 0x0f) | 0x30;
  hash[8] = (hash[8] & 0x3f) | 0x80;
  const hex = hash.toString('hex');
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20,32)}`;
}

/**
 * Validate whether a string is a well-formed UUID.
 * @param   {string} uuid
 * @returns {boolean}
 */
function validarUUID(uuid) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(uuid);
}

/**
 * Strip hyphens from a UUID string.
 * @param   {string} uuid
 * @returns {string} 32-char hex string
 */
function uuidToHex(uuid) {
  return uuid.replace(/-/g, '');
}

/**
 * Add hyphens to a 32-char hex string.
 * @param   {string} hex
 * @returns {string} UUID string
 */
function hexToUUID(hex) {
  if (hex.length !== 32) throw new Error('Expected a 32-character hex string');
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}

module.exports = { generarUUID, validarUUID, uuidToHex, hexToUUID };
